/* Shared helpers for the development pages. All text is inserted with textContent (no innerHTML). */
window.HH = (function () {
  async function api(path, method, body) {
    const options = { method: method || "GET", headers: {}, credentials: "same-origin" };
    if (body !== undefined) {
      options.headers["Content-Type"] = "application/json";
      options.body = JSON.stringify(body);
    }
    try {
      const res = await fetch(path, options);
      let data = null;
      try { data = await res.json(); } catch (e) { /* no body */ }
      return { ok: res.ok, status: res.status, data: data };
    } catch (e) {
      return { ok: false, status: 0, data: { error: { message: "Cannot reach the server." } } };
    }
  }

  function showError(el, res) {
    el.textContent = "";
    const err = res.data && res.data.error;
    const detail = res.data && res.data.detail;
    const top = document.createElement("div");
    top.textContent = err ? err.message : (typeof detail === "string" ? detail : "Something went wrong.");
    el.appendChild(top);
    if (err && err.details) {
      err.details.forEach(function (d) {
        const line = document.createElement("div");
        line.textContent = d.field + ": " + d.message;
        el.appendChild(line);
      });
    } else if (Array.isArray(detail)) {
      detail.forEach(function (d) {
        const line = document.createElement("div");
        line.textContent = (d.loc || []).slice(1).join(".") + ": " + d.msg;
        el.appendChild(line);
      });
    }
  }

  function renderPlayers(listEl, players) {
    listEl.textContent = "";
    players.forEach(function (p) {
      const li = document.createElement("li");
      const dot = document.createElement("span");
      dot.className = "dot";
      dot.style.background = p.pawn_color;
      li.appendChild(dot);
      li.appendChild(document.createTextNode(p.display_name));
      listEl.appendChild(li);
    });
  }

  return { api: api, showError: showError, renderPlayers: renderPlayers };
})();
