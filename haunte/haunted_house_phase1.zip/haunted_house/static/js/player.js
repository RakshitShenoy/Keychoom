(function () {
  const HH = window.HH;
  const $ = function (id) { return document.getElementById(id); };
  let timer = null;

  function showLobby(info) {
    $("join-card").classList.add("hidden");
    $("lobby-card").classList.remove("hidden");
    $("me-name").textContent = info.display_name;
    $("game-code").textContent = info.game_code;
    $("game-status").textContent = info.status;
  }

  async function poll() {
    const res = await HH.api("/api/player/lobby");
    if (!res.ok) { return; }
    $("game-status").textContent = res.data.status;
    HH.renderPlayers($("player-list"), res.data.players);
  }

  function startPolling() {
    poll();
    if (!timer) { timer = setInterval(poll, 3000); }
  }

  async function restoreSession() {
    const res = await HH.api("/api/me");
    if (res.ok && res.data.player) {
      showLobby(res.data.player);
      startPolling();
    }
  }

  $("join-form").addEventListener("submit", async function (event) {
    event.preventDefault();
    const res = await HH.api("/api/games/join", "POST", {
      game_code: $("game_code").value,
      display_name: $("display_name").value
    });
    if (!res.ok) { HH.showError($("join-error"), res); return; }
    $("join-error").textContent = "";
    showLobby(res.data);
    startPolling();
  });

  restoreSession();
})();
