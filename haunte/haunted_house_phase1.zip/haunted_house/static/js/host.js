(function () {
  const HH = window.HH;
  const $ = function (id) { return document.getElementById(id); };
  let timer = null;

  function showGame(info) {
    $("create-card").classList.add("hidden");
    $("game-card").classList.remove("hidden");
    $("game-code").textContent = info.game_code;
    $("game-status").textContent = info.status;
  }

  async function poll() {
    const res = await HH.api("/api/host/game");
    if (!res.ok) { return; }
    $("game-status").textContent = res.data.status;
    $("player-count").textContent = res.data.player_count + " / " + res.data.capacity;
    HH.renderPlayers($("player-list"), res.data.players);
  }

  function startPolling() {
    poll();
    if (!timer) { timer = setInterval(poll, 3000); }
  }

  async function restoreSession() {
    const res = await HH.api("/api/me");
    if (res.ok && res.data.host) {
      showGame(res.data.host);
      startPolling();
    }
  }

  $("create-form").addEventListener("submit", async function (event) {
    event.preventDefault();
    const body = {};
    const map = {
      min_teams: "min_teams", max_teams: "max_teams",
      min_players_per_team: "min_players_per_team", max_players_per_team: "max_players_per_team"
    };
    Object.keys(map).forEach(function (field) {
      const raw = $(field).value.trim();
      if (raw !== "") { body[field] = Number(raw); }
    });
    const minutes = $("base_duration_minutes").value.trim();
    if (minutes !== "") { body.base_duration_seconds = Math.round(Number(minutes) * 60); }

    const res = await HH.api("/api/games", "POST", body);
    if (!res.ok) { HH.showError($("create-error"), res); return; }
    $("create-error").textContent = "";
    showGame(res.data);
    startPolling();
  });

  restoreSession();
})();
