# Escape the Haunted House

A Halloween-themed, competitive, multiplayer escape-room game: one host per lobby, 3-25 teams of
3-10 players, eight floors of interconnected puzzles, and the first team to escape wins.

> **Status: Phase 1 of the plan. The game is NOT complete.** This phase delivers only the backend
> foundation: configuration, database + migrations, anonymous host/player sessions, creating a
> lobby, joining it, and the plumbing for content loading. There is no gameplay yet.

## 1. Requirements

- Python 3.11 or newer (developed on 3.12)
- `pip` and the built-in `venv` module
- Nothing else: the database is a local SQLite file

## 2. Installation

```bash
git clone <your-github-url> haunted_house
cd haunted_house
```

## 3. Virtual environment

```bash
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
```

## 4. Dependencies

```bash
pip install -r requirements-dev.txt     # app + test tools
# production only: pip install -r requirements.txt
```

## 5. Environment configuration

```bash
cp .env.example .env
```

Edit `.env`. At minimum set a private `SECRET_KEY`:

```bash
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

`.env` is git-ignored: **never commit it**. Every limit (team/player counts, hint penalties, lock
lease, heartbeat, session lifetimes) is configurable there; see `.env.example` and `app/config.py`.
Settings that contradict each other (for example 3 hint penalties but `MAX_HINTS=4`) stop the
server from starting.

## 6. Database migrations

Run all commands from the project root.

```bash
alembic upgrade head       # creates ./haunted_house.db and all tables
alembic current            # shows the applied revision (0001)
alembic downgrade base     # removes everything (development only)
```

After you change a model, create a new migration with
`alembic revision --autogenerate -m "describe the change"`, **read it**, then `alembic upgrade head`.

## 7. Run the server

```bash
uvicorn app.main:app --reload --port 8000     # development
```

Use **one worker** (never `--workers N`): live game state will be kept in memory in later phases.
Behind a proxy such as Replit's, add `--proxy-headers --forwarded-allow-ips='*'`.

Open <http://localhost:8000>. Health check: <http://localhost:8000/health> returns `{"status":"ok"}`.
Interactive API docs: <http://localhost:8000/docs>.

## 8. Run the tests

```bash
pytest
```

Each test uses its own temporary SQLite file, so tests never touch your real database.

## 9. Project structure

```
app/
  main.py          application factory, router wiring, startup content validation
  config.py        all configuration (env-driven, validated)
  errors.py        AppError (stable error codes)   error_handlers.py  JSON error responses
  db/              base.py (naming convention, engine), session.py, types.py, enums.py, ids.py
    models/        one module per table group (11 tables)
    migrations/    Alembic environment + versions/0001_initial_schema.py
  auth/            tokens (hashing), sessions (cookies), dependencies, /api/me, rate limiter
  lobby/           codes.py, names.py, service.py (create/join rules), router.py, pages.py
  teams/           pawns.py + /api/player/lobby   (team formation comes in Phase 2)
  host/            /api/host/game                 (full dashboard comes later)
  content/         loader.py + presets/ puzzles/ quizzes/ dares/ (empty on purpose)
  timers/          clock.py, deadline.py (team deadline formula)
  hints/           penalties.py
  game/ engines/ jumpscares/ ws/   empty packages reserved for later phases
  schemas/         Pydantic request/response models
static/            css/ js/ img/ audio/ video/
templates/         landing, host and player development pages
tests/             pytest suite
alembic.ini  requirements*.txt  .env.example  pytest.ini
```

## 10. What works in Phase 1

| Area | Details |
|---|---|
| `GET /health` | `{"status":"ok"}` |
| `POST /api/games` | Host creates a lobby; limits validated; unique readable game code; host cookie set. Status `LOBBY`. |
| `POST /api/games/join` | Player joins with game code + display name; validates game, status, capacity, name. `team_id` is null. |
| `GET /api/me` | Who am I? Returns the host and/or player session so pages survive a refresh. |
| `GET /api/host/game`, `GET /api/player/lobby` | Minimal lobby views (polling) so you can watch joins. |
| Pages `/`, `/host`, `/player` | Plain functional pages with role-specific rules. Not the final UI. |
| Sessions | Random 256-bit tokens in HttpOnly cookies; only keyed hashes are stored in the database. |
| Database | 11 tables, unique keys and CHECK constraints, SQLite now and PostgreSQL-compatible. |
| Content | Loader for JSON/YAML with validation hooks; invalid content stops startup. No puzzles yet. |
| Join guess protection | Repeated wrong game codes from one IP are blocked for a minute (valid joins never count). |

## 11. Not implemented yet (later phases)

Team formation and team codes, public-chat shutdown, host start/cutscene, WebSockets, the eight
floors and puzzles, quizzes, dares, hints in play, timers in play, jumpscares, the host
dashboard, the room renderer, the winner logic, and the polished haunted UI.

## 12. Known Phase 1 limits

- `games.winner_team_id` and `teams.leader_player_id` have no foreign key yet (the tables reference
  each other). Phase 2 adds them with a migration, together with the code that uses them.
- The join-guess limiter is in memory and per process (fine for the single-worker design).
- Session cookies use `Secure` only when `COOKIE_SECURE=true`; set it when serving over HTTPS.
- Sessions have a fixed lifetime (12 hours by default).
