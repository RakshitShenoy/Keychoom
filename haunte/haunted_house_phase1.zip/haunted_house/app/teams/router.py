from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.auth.dependencies import require_player
from app.db.models import Player
from app.db.session import get_db
from app.schemas.player import LobbyPlayerOut, PlayerLobbyResponse

router = APIRouter(tags=["player"])


def _lobby_player(p: Player) -> LobbyPlayerOut:
    return LobbyPlayerOut(display_name=p.display_name, pawn_color=p.pawn_color, team_id=p.team_id)


@router.get("/api/player/lobby", response_model=PlayerLobbyResponse)
def player_lobby(
    player: Player = Depends(require_player), db: Session = Depends(get_db)
) -> PlayerLobbyResponse:
    """What a player sees in the lobby (team formation arrives in Phase 2)."""
    others = db.scalars(
        select(Player).where(Player.game_id == player.game_id).order_by(Player.joined_at, Player.id)
    ).all()
    return PlayerLobbyResponse(
        game_code=player.game.game_code,
        status=player.game.status,
        you=_lobby_player(player),
        players=[_lobby_player(p) for p in others],
    )
