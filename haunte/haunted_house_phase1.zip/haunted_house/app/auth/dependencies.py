from __future__ import annotations

from fastapi import Depends, Request
from sqlalchemy.orm import Session

from app.auth.sessions import resolve_host_game, resolve_player
from app.db.models import Game, Player
from app.db.session import get_db
from app.errors import AppError


def require_host(request: Request, db: Session = Depends(get_db)) -> Game:
    settings = request.app.state.settings
    game = resolve_host_game(db, settings, request.cookies.get(settings.host_cookie_name))
    if game is None:
        raise AppError(401, "HOST_SESSION_REQUIRED", "A valid host session is required.")
    return game


def require_player(request: Request, db: Session = Depends(get_db)) -> Player:
    settings = request.app.state.settings
    player = resolve_player(db, settings, request.cookies.get(settings.player_cookie_name))
    if player is None:
        raise AppError(401, "PLAYER_SESSION_REQUIRED", "A valid player session is required.")
    return player
