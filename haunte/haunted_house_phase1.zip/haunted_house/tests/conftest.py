import pytest
from fastapi.testclient import TestClient

import app.db.models  # noqa: F401  (register models on Base.metadata)
from app.config import Settings
from app.db.base import Base
from app.main import create_app


@pytest.fixture
def settings(tmp_path):
    return Settings(
        _env_file=None,  # never read a developer's local .env during tests
        app_env="test",
        database_url=f"sqlite:///{tmp_path / 'test.db'}",
        secret_key="test-secret-key",
        join_failure_limit=3,
    )


@pytest.fixture
def app(settings):
    application = create_app(settings)
    Base.metadata.create_all(application.state.db.engine)
    return application


@pytest.fixture
def client(app):
    with TestClient(app) as test_client:
        yield test_client


@pytest.fixture
def db(app):
    session = app.state.db.session_factory()
    try:
        yield session
    finally:
        session.close()


@pytest.fixture
def make_game(client):
    def _make(**overrides):
        return client.post("/api/games", json=overrides)

    return _make
