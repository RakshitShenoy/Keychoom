from pathlib import Path

from alembic import command
from alembic.autogenerate import compare_metadata
from alembic.config import Config
from alembic.migration import MigrationContext
from sqlalchemy import create_engine, inspect

import app.db.models  # noqa: F401
from app.db.base import Base

ROOT = Path(__file__).resolve().parent.parent
EXPECTED_TABLES = {
    "games", "players", "teams", "team_floor_state", "object_state", "hint_usage",
    "quiz_attempts", "dare_confirmations", "jumpscare_events", "chat_messages", "game_events",
}


def alembic_config(url: str) -> Config:
    cfg = Config(str(ROOT / "alembic.ini"))
    cfg.set_main_option("script_location", str(ROOT / "app" / "db" / "migrations"))
    cfg.set_main_option("sqlalchemy.url", url)
    return cfg


def test_upgrade_creates_all_tables_and_downgrade_removes_them(tmp_path):
    url = f"sqlite:///{tmp_path / 'migrate.db'}"
    cfg = alembic_config(url)

    command.upgrade(cfg, "head")
    engine = create_engine(url)
    assert EXPECTED_TABLES <= set(inspect(engine).get_table_names())

    command.downgrade(cfg, "base")
    assert EXPECTED_TABLES.isdisjoint(set(inspect(engine).get_table_names()))
    engine.dispose()


def test_migration_matches_the_models(tmp_path):
    """Guards against the models and the hand-written migration drifting apart."""
    url = f"sqlite:///{tmp_path / 'drift.db'}"
    command.upgrade(alembic_config(url), "head")
    engine = create_engine(url)
    with engine.connect() as connection:
        context = MigrationContext.configure(connection, opts={"compare_type": True})
        differences = compare_metadata(context, Base.metadata)
    engine.dispose()
    assert differences == []
